export declare class DeviceDirectory {
    apiClient: any;
    isSuccessResponse: (resp: any) => boolean;
    getResponseData: (resp: any) => any;
    remoteDevicesCache: Map<any, any>;
    remoteDevicesInFlight: Map<any, any>;
    remoteDevicesCacheTtlMs: number;
    channelDevicesCache: Map<any, any>;
    channelDevicesInFlight: Map<any, any>;
    channelDevicesCacheTtlMs: number;
    constructor(apiClient: any, isSuccessResponse: (resp: any) => boolean, getResponseData: (resp: any) => any);
    getRemoteDevices(uid: string, forceRefresh?: boolean): Promise<any>;
    getChanelSubscribersDevices(channelId: string, channelType: any, forceRefresh?: boolean): Promise<any>;
}
