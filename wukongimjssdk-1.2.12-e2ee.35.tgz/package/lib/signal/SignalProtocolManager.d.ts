import CryptoJS from 'crypto-js';
import { DeviceDirectory } from './managers/DeviceDirectory';
import { PreKeyManager } from './managers/PreKeyManager';
import { SessionManager } from './managers/SessionManager';
import { GroupManager } from './managers/GroupManager';
import { KeyBundleDirectory } from './managers/KeyBundleDirectory';
export declare class SignalProtocolManager {
    uid: any;
    deviceId: any;
    deviceName: any;
    apiClient: any;
    store: any;
    curve: any;
    webcrypto: any;
    deviceDirectory: DeviceDirectory;
    keyBundleDirectory: KeyBundleDirectory;
    preKeyManager: PreKeyManager;
    sessionManager: SessionManager;
    groupManager: GroupManager;
    constructor(uid: any, apiClient: any, options?: {
        deviceId?: any;
        deviceName?: any;
    });
    get remoteDevicesCacheTtlMs(): number;
    set remoteDevicesCacheTtlMs(value: number);
    get channelDevicesCacheTtlMs(): number;
    set channelDevicesCacheTtlMs(value: number);
    isSuccessResponse(resp: any): boolean;
    getResponseData(resp: any): any;
    initialize(): Promise<{
        uploadedKeys: boolean;
        newIdentity: boolean;
        identityRepaired: boolean;
    }>;
    getSessionCompatibilityMigrationKey(): string;
    applySessionCompatibilityMigration(): Promise<void>;
    clearLocalData(): Promise<void>;
    handleLocalIdentityRepaired(): void;
    handleLocalKeyRegistrationComplete(): void;
    generateRegistrationId(): number;
    getPreKeyNextIdStorageKey(): string;
    generateSignedPreKey(keyId: any, identityKeyPair: any): Promise<any>;
    generatePreKeys(startId: number, count: number): Promise<any[]>;
    generatePreKeyBundle(): Promise<{
        uid: any;
        device_id: any;
        device_name: any;
        platform: string;
        identity_key: string;
        registration_id: number;
        signed_prekey: {
            key_id: number;
            public_key: string;
            signature: string;
        };
        prekeys: {
            key_id: any;
            public_key: string;
        }[];
    }>;
    uploadPreKeys(bundle: any): Promise<any>;
    uploadOnetimePreKeys(bundle: any): Promise<any>;
    useOnetimePreKeys(bundle: any): Promise<any>;
    maybeCheckAndRefillPreKeys(): void;
    checkAndRefillPreKeys(): Promise<void>;
    rotateSignedPreKey(): Promise<void>;
    startMaintenance(): void;
    stopMaintenance(): void;
    buildSession(remoteUid: string, remoteDeviceId: any): Promise<void>;
    hasSession(remoteUid: string, remoteDeviceId: any): Promise<boolean>;
    deleteSession(remoteUid: string, remoteDeviceId: any): Promise<void>;
    encryptMessage(remoteUid: string, remoteDeviceId: any, plaintext: string): Promise<{
        type: any;
        body: string;
    }>;
    decryptSignalCipherMessage(remoteUid: string, remoteDeviceId: any, messageType: any, ciphertext: any): Promise<string>;
    ensureTrustedIdentityKey(remoteUid: string, remoteDeviceId: any, identityKey: any): Promise<void>;
    getRemoteKeyBundle(remoteUid: string, remoteDeviceId: any): Promise<any>;
    decryptMessage(remoteUid: string, remoteDeviceId: any, messageType: any, ciphertext: any): Promise<any>;
    encryptGroupMessage(groupId: any, plaintext: string, members: any, memberHash: any): Promise<any>;
    prepareGroupSend(groupId: any, members: any, memberHash: any): Promise<any>;
    buildGroupDistributionMessage(groupId: any, memberHash: any, forceNewKey: boolean): Promise<{
        plain: string;
        keyId: any;
        memberHash: any;
        kdfVersion: any;
    } | null>;
    encryptGroupDistribution(groupId: any, members: any, memberHash: any, forceNewKey: boolean): Promise<{
        type: number;
        body: string;
    } | null>;
    decryptGroupMessageObject(obj: any, remoteUid: string, remoteDeviceId: any): Promise<any>;
    recoverGroupMessageDecryptFailure(obj: any, remoteUid: string, remoteDeviceId: any): Promise<boolean>;
    decryptGroupDistributionObject(obj: any, remoteUid: string, remoteDeviceId: any): Promise<void>;
    uploadGroupSenderKeyEnvelopes(payload: any): Promise<any>;
    lookupGroupSenderKeyEnvelope(payload: any): Promise<any>;
    requestGroupSenderKeyRepair(payload: any): Promise<any>;
    lookupGroupSenderKeyRepairRequests(payload: any): Promise<any>;
    normalizeMemberHash(memberHash: any, members: any): any;
    createSenderKeyRecord(groupId: any, memberHash: any, existingRecord: any): Promise<any>;
    createSenderKeyState(existingRecord: any): Promise<import("./models/SenderKeyState").SenderKeyState>;
    loadSenderKeyRecord(groupId: any, senderUid: any, senderDeviceId: any): Promise<import("./models/SenderKeyRecord").SenderKeyRecord | null>;
    saveSenderKeyRecord(groupId: any, senderUid: any, record: any, senderDeviceId: any): Promise<void>;
    /**
     * 删除指定的 sender key 记录
     * @param groupId 群组 ID
     * @param senderUid 发送者用户 ID
     * @param senderDeviceId 发送者设备 ID（可选）
     */
    deleteSenderKeyRecord(groupId: any, senderUid: any, senderDeviceId?: any): Promise<void>;
    /**
     * 删除指定群组的所有 sender keys
     * @param groupId 群组 ID
     */
    deleteGroupSenderKeys(groupId: string): Promise<void>;
    /**
     * 删除指定用户的所有 sender keys（跨所有群组）
     * @param senderUid 发送者用户 ID
     */
    deleteUserSenderKeys(senderUid: string): Promise<void>;
    getRemoteDevices(uid: string, forceRefresh?: boolean): Promise<any>;
    getChanelSubscribersDevices(channelId: string, channelType: any, forceRefresh?: boolean): Promise<any>;
    invalidateChannelDevicesCache(channelId: string, channelType?: any): void;
    invalidateGroupRepairRequestCache(groupId: string): void;
    ensureWebCrypto(): void;
    getSubtleCrypto(): any;
    getCurve(): Promise<any>;
    selectCiphertextForDevice(ciphertexts: any[], uid: any, deviceId: any): any;
    encryptGroupDistributionForDevice(recipientUid: string, distributionPlain: string, devices?: any[]): Promise<any[]>;
    normalizeProvidedKeyBundles(recipientUid: string, devices?: any[]): any[];
    encryptGroupDistributionForDeviceIdentity(recipientUid: string, recipientDeviceId: string, identityKey: string, distributionPlain: string): Promise<any[] | undefined>;
    decryptGroupDistributionForDevice(ciphertext: any): Promise<string>;
    signGroupPayload(signingPrivKeyBase64: string, groupId: any, senderUid: any, msgIndex: any, ivBase64: any, bodyBase64: any, macBase64: any, enc: any, tagBase64: any): Promise<string>;
    verifyGroupSignature(signingPubKeyBase64: string, groupId: any, senderUid: any, msgIndex: any, ivBase64: any, bodyBase64: any, macBase64: any, signatureBase64: string, enc: any, tagBase64: any): Promise<any>;
    encryptGroupPayload(messageKeyBase64: string, msgIndex: any, plaintext: string, kdfVersion: string): Promise<{
        iv: string;
        body: string;
        tag: string;
        enc: string;
        mac?: undefined;
    } | {
        iv: string;
        body: string;
        mac: string;
        enc: string;
        tag?: undefined;
    }>;
    decryptGroupPayload(messageKeyBase64: string, msgIndex: any, ivBase64: any, bodyBase64: any, macBase64: any, tagBase64: any, enc: any): Promise<string>;
    randomBytes(length: number): Uint8Array;
    hkdfSha256Bytes(ikmBuffer: any, saltText: any, infoText: any, lengthBytes: number): Uint8Array;
    hkdfExpandWord(prkWord: any, info: any, lengthBytes: number): CryptoJS.lib.WordArray;
    arrayBufferToWordArray(buffer: any): CryptoJS.lib.WordArray;
    wordArrayToUint8Array(wordArray: any): Uint8Array;
    toBase64(buffer: any): string;
    fromBase64(str: any): ArrayBuffer;
    stringToArrayBuffer(str: string): ArrayBuffer | SharedArrayBuffer;
    arrayBufferToString(buffer: any): string;
    getDeviceIdFromStorage(): string;
    generateUUID(): string;
    getOSAndVersion(): string;
}
