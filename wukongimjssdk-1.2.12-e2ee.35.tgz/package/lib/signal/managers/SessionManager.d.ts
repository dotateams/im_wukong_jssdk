import { SignalProtocolStore } from '../storage/SignalProtocolStore';
export interface IAPIClient {
    get(url: string): Promise<any>;
}
export interface SessionManagerParams {
    uid: string;
    deviceId: string | number;
    apiClient: IAPIClient;
    store: SignalProtocolStore;
    isSuccessResponse: (resp: any) => boolean;
    getResponseData: (resp: any) => any;
    toBase64: (data: any) => string;
    fromBase64: (data: any) => any;
    stringToArrayBuffer: (s: string) => ArrayBuffer;
    arrayBufferToString: (b: any) => string;
    ensureWebCrypto: () => void;
    maybeCheckAndRefillPreKeys: () => void;
    useOnetimePreKeys: (bundle: any) => Promise<any>;
    getRemoteKeyBundle?: (uid: string, deviceId: string | number) => Promise<any>;
}
export declare class SessionManager {
    uid: string;
    deviceId: string | number;
    apiClient: IAPIClient;
    store: SignalProtocolStore;
    getResponseData: (resp: any) => any;
    isSuccessResponse: (resp: any) => boolean;
    toBase64: (data: any) => string;
    fromBase64: (data: any) => any;
    stringToArrayBuffer: (s: string) => ArrayBuffer;
    arrayBufferToString: (b: any) => string;
    ensureWebCrypto: () => void;
    sessionBuildingLocks: Map<string, Promise<void>>;
    maybeCheckAndRefillPreKeys: () => void;
    useOnetimePreKeys: (bundle: any) => Promise<any>;
    getRemoteKeyBundle: (uid: string, deviceId: string | number) => Promise<any>;
    private sessionCache;
    constructor(params: SessionManagerParams);
    private updateSessionCache;
    /**
     * 获取缓存统计信息
     */
    getCacheStats(): {
        size: number;
        hitRate: number;
    };
    buildSession(remoteUid: string, remoteDeviceId: string | number): Promise<void>;
    resolveBundleWithClaimedPreKey(remoteUid: string, remoteDeviceId: string | number, bundleData: any): Promise<any>;
    hasSession(remoteUid: string, remoteDeviceId: string | number): Promise<boolean>;
    deleteSession(remoteUid: string, remoteDeviceId: string | number): Promise<void>;
    clearSessionCache(): void;
    isRecoverablePreKeySessionError(messageType: any, message: string): boolean;
    encryptMessage(remoteUid: string, remoteDeviceId: string | number, plaintext: string): Promise<{
        type: any;
        body: string;
    }>;
    decryptSignalCipherMessage(remoteUid: string, remoteDeviceId: string | number, messageType: any, ciphertext: any): Promise<string>;
    ensureTrustedIdentityKey(remoteUid: string, remoteDeviceId: string | number, identityKey: any): Promise<void>;
    /**
     * 生成安全指纹 (Safety Number/Fingerprint)
     * 用于防范中间人攻击(MITM)。用户可通过面对面扫码或外部渠道核对该指纹。
     * 算法：对本地身份公钥和远端身份公钥进行联合哈希。
     */
    getFingerprint(remoteUid: string, remoteDeviceId: string | number): Promise<string | null>;
    toSignalDeviceId(deviceId: string | number): number;
    private normalizeSignalDeviceIdNumber;
}
