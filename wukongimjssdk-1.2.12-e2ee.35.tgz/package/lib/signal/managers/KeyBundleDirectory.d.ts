export declare type NormalizedKeyBundle = {
    uid: string;
    deviceId: string;
    identityKey: string;
    registrationId?: number;
    signedPrekey?: {
        keyId: number;
        publicKey: string;
        signature: string;
    };
    prekey?: {
        keyId: number;
        publicKey: string;
    };
    protocolVersion?: number;
};
export declare class KeyBundleDirectory {
    apiClient: any;
    isSuccessResponse: (resp: any) => boolean;
    getResponseData: (resp: any) => any;
    cache: Map<string, {
        bundles: NormalizedKeyBundle[];
        fetchedAt: number;
    }>;
    inFlight: Map<string, Promise<NormalizedKeyBundle[]>>;
    cacheTtlMs: number;
    constructor(apiClient: any, isSuccessResponse: (resp: any) => boolean, getResponseData: (resp: any) => any);
    clearCache(): void;
    normalize(raw: any): NormalizedKeyBundle | null;
    getUserKeyBundles(uid: string, forceRefresh?: boolean): Promise<NormalizedKeyBundle[]>;
    getDeviceKeyBundle(uid: string, deviceId: any, forceRefresh?: boolean): Promise<NormalizedKeyBundle | null>;
}
