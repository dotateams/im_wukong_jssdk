import { SenderKeyState } from "./SenderKeyState";
export declare class SenderKeyRecord {
    memberHash: string;
    states: SenderKeyState[];
    createdAt: number;
    updatedAt: number;
    constructor({ memberHash, states, createdAt, updatedAt }: any);
    static fromStorage(obj: any): SenderKeyRecord | null;
    serialize(): {
        member_hash: string;
        states: {
            key_id: any;
            sender_key: any;
            chain_key: any;
            msg_index: number;
            skipped: any;
            signing_pub_key: any;
            signing_priv_key: any;
            kdf_ver: string;
        }[];
        created_at: number;
        updated_at: number;
    };
    touch(): void;
    getState(): SenderKeyState | null;
    getStateByKeyId(keyId: any): SenderKeyState | null;
    addState(state: SenderKeyState): void;
}
