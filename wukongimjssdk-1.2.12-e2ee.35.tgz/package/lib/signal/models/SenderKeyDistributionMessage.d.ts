export declare class SenderKeyDistributionMessage {
    groupId: any;
    senderUid: any;
    senderDeviceId: any;
    keyId: any;
    senderKey: any;
    signingPubKey: any;
    memberHash: string;
    kdfVersion: string;
    constructor({ groupId, senderUid, senderDeviceId, keyId, senderKey, signingPubKey, memberHash, kdfVersion, }: any);
    static fromString(raw: string): SenderKeyDistributionMessage | null;
    toString(): string;
}
