export declare function toBase64(buffer: any): string;
export declare function fromBase64(str: any): ArrayBuffer;
