export declare function generateUUID(): string;
export declare function getDeviceIdFromStorage(): string;
export declare function getOSAndVersion(): string;
