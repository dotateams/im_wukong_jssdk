import CryptoJS from 'crypto-js';
export declare function arrayBufferToWordArray(buffer: any): CryptoJS.lib.WordArray;
export declare function wordArrayToUint8Array(wordArray: any): Uint8Array;
export declare function hkdfExpandWord(prkWord: any, info: any, lengthBytes: number): CryptoJS.lib.WordArray;
export declare function hkdfSha256Bytes(ikmBuffer: any, saltText: any, infoText: any, lengthBytes: number): Uint8Array;
