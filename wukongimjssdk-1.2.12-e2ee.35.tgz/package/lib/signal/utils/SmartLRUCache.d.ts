/**
 * 智能LRU缓存实现
 * 支持TTL过期、LRU淘汰、统计信息
 */
export declare class SmartLRUCache<K, V> {
    private cache;
    private readonly maxSize;
    private readonly ttlMs;
    private hits;
    private misses;
    constructor(options?: {
        maxSize?: number;
        ttlMs?: number;
    });
    get(key: K): V | undefined;
    set(key: K, value: V): void;
    has(key: K): boolean;
    delete(key: K): boolean;
    clear(): void;
    /**
     * 获取所有键
     */
    keys(): K[];
    /**
     * 获取所有值
     */
    values(): V[];
    /**
     * 获取所有条目
     */
    entries(): [K, V][];
    private evict;
    getStats(): {
        size: number;
        hits: number;
        misses: number;
        hitRate: number;
    };
    get size(): number;
}
