export declare function randomBytes(length: number): Uint8Array;
export declare function stringToArrayBuffer(str: string): ArrayBuffer | SharedArrayBuffer;
export declare function arrayBufferToString(buffer: any): string;
