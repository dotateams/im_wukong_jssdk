import { SenderKeyRecord } from "../models/SenderKeyRecord";
export declare class GroupCipher {
    manager: any;
    record: SenderKeyRecord;
    groupId: any;
    senderUid: any;
    constructor(manager: any, record: SenderKeyRecord, groupId: any, senderUid: any);
    encrypt(plaintext: string): Promise<{
        state: any;
        payload: {
            type: string;
            group_id: any;
            sender_uid: any;
            key_id: any;
            msg_index: any;
            iv: any;
            body: any;
            mac: any;
            tag: any;
            enc: any;
            kdf_ver: any;
            signature: any;
            signing_pub_key: any;
        };
    }>;
    decrypt(obj: any): Promise<any>;
}
