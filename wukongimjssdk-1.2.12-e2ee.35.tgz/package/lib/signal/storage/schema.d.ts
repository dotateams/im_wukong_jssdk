export declare const STORES: {
    IDENTITY_KEYS: string;
    PRE_KEYS: string;
    USED_PRE_KEYS: string;
    SIGNED_PRE_KEYS: string;
    SESSIONS: string;
    KYBER_PRE_KEYS: string;
    SENDER_KEYS: string;
};
export declare function openDatabase(uid: string, deviceId: string | number): Promise<IDBDatabase>;
