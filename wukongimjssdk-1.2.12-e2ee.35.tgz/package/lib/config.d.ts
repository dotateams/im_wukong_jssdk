import { IProto } from "./proto";
import { Provider } from "./provider";
import { E2EEManager } from "./e2ee/e2ee_manager";
import type { E2EEInitOptions } from "./e2ee/e2ee_types";
export declare class WKConfig {
    constructor();
    debug: boolean;
    addr: string;
    uid?: string;
    token?: string;
    protoVersion: number;
    deviceFlag: number;
    proto: IProto;
    heartbeatInterval: number;
    provider: Provider;
    e2ee: E2EEManager;
    receiptFlushInterval: number;
    sdkVersion: string;
    platform?: any;
    sendFrequency: number;
    sendCountOfEach: number;
    clientMsgDeviceId: number;
    initE2EE(options: E2EEInitOptions): Promise<void>;
}
