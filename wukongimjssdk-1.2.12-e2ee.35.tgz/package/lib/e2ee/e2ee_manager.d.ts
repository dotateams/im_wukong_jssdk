import type { Channel, MediaMessageContent, MessageContent } from "../model";
import type { E2EEDecryptContext, E2EEInitOptions, E2EERecoverContext, E2EESendPlan, ResolveSendPlanOptions } from "./e2ee_types";
import { SaveOriginalOptions } from "./e2ee_media";
export declare class E2EEManager {
    private options?;
    private mediaCrypto?;
    private state;
    private readyAtTimestamp;
    get initialized(): boolean;
    get readyState(): "idle" | "pending" | "ready" | "failed";
    get isReady(): boolean;
    get readyAt(): number;
    get currentOptions(): E2EEInitOptions | undefined;
    initialize(options: E2EEInitOptions): Promise<void>;
    reset(): void;
    clearLocalPlaintextData(): Promise<void>;
    clearLocalData(): Promise<void>;
    resolveSendPlan(channel: Channel, _content: MessageContent, options?: ResolveSendPlanOptions): Promise<E2EESendPlan>;
    encryptMessage(content: MessageContent, channel: Channel): Promise<MessageContent>;
    prewarmChannel(channel: Channel): Promise<void>;
    prepareGroupSend(channel: Channel): Promise<void>;
    invalidateGroupMemberCache(channel: Channel): void;
    invalidateGroupRepairRequestCache(channel: Channel): void;
    redistributeGroup(channel: Channel): Promise<void>;
    canEncryptMedia(content: MessageContent): boolean;
    encryptMediaMessage(content: MediaMessageContent, channel: Channel): Promise<MessageContent>;
    decryptMessage(content: MessageContent, channel: Channel, context?: E2EEDecryptContext): Promise<MessageContent>;
    recoverDecryptFailure(content: MessageContent, channel: Channel, context?: E2EERecoverContext): Promise<boolean>;
    shouldCachePlaintext(content: MessageContent, channel?: Channel): boolean;
    cacheablePlaintextContent(content: MessageContent, channel?: Channel): MessageContent | undefined;
    restoreCachedPlaintext(content: MessageContent, channel?: Channel): Promise<MessageContent>;
    loadMediaOriginal(content: MessageContent, options?: SaveOriginalOptions): Promise<string | undefined>;
    loadMediaOriginalBlob(content: MessageContent, options?: SaveOriginalOptions): Promise<Blob | undefined>;
    saveMediaOriginal(content: MessageContent, fileName?: string, options?: SaveOriginalOptions): Promise<boolean>;
    loadMediaThumbnail(content: MessageContent): Promise<string | undefined>;
    prepareReusableMediaForwardContent(content: MessageContent): MessageContent | undefined;
    canForwardE2EEMedia(content: MessageContent): {
        ok: true;
    } | {
        ok: false;
        reason: string;
    };
    private clearPlaintextStorage;
    private getStorage;
    private resolveChannelInfo;
    private preflightChannelInfo;
    private normalizeChannelInfo;
    private normalizeOptions;
}
