declare type DeviceDirectoryOptions = {
    uid?: string;
    deviceId?: string | number;
};
export declare class DeviceDirectory {
    apiClient: any;
    isSuccessResponse: (resp: any) => boolean;
    getResponseData: (resp: any) => any;
    uid?: string;
    deviceId?: string | number;
    remoteDevicesCache: Map<any, any>;
    remoteDevicesInFlight: Map<any, any>;
    remoteDevicesCacheTtlMs: number;
    channelDevicesCache: Map<any, any>;
    channelDevicesInFlight: Map<any, any>;
    channelDevicesRefreshGeneration: Map<any, number>;
    channelDevicesCacheTtlMs: number;
    constructor(apiClient: any, isSuccessResponse: (resp: any) => boolean, getResponseData: (resp: any) => any, options?: DeviceDirectoryOptions);
    getRemoteDevices(uid: string, forceRefresh?: boolean): Promise<any>;
    getChanelSubscribersDevices(channelId: string, channelType: any, forceRefresh?: boolean, options?: {
        awaitFreshness?: boolean;
    }): Promise<any>;
    getChannelDevicesRefreshPromise(channelId: string, channelType: any): any;
    invalidateChannelDevicesCache(channelId: string, channelType?: any): void;
    clearLocalData(): void;
    private scheduleChannelDevicesRefresh;
    private refreshChannelDevices;
    private fetchAndStoreChannelDevices;
    private validateChannelDevicesVersionAndRefresh;
    private fetchChannelDevicesVersion;
    private normalizeChannelDevices;
    private isChannelDevicesCacheExpired;
    private getChannelDevicesCacheEntry;
    private getChannelDevicesCacheKey;
    private getPersistentChannelDevicesKey;
    private getPersistentChannelDevicesPrefix;
    private getPersistentChannelDevices;
    private setPersistentChannelDevices;
    private removePersistentChannelDevices;
    private clearPersistentChannelDevices;
}
export {};
