export declare function utf8BytesToString(data: Uint8Array): string;
