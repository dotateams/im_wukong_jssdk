/**
 * E2EE配置接口和管理器
 */
export interface E2EEConfig {
    groupDistributionDebounceMs: number;
    groupRotationDebounceMs: number;
    groupDistributionConcurrency: number;
    senderKeyEnvelopeConcurrency: number;
    senderKeyEnvelopeUploadBatchSize: number;
    senderKeyEnvelopeUploadTargetBytes: number;
    senderKeyEnvelopeUploadConcurrency: number;
    senderKeyDistributionInterval: number;
    maxBatchSize: number;
    minBatchSize: number;
    maxDevicesPerUser: number;
    senderKeyTTL: number;
    sessionCacheTTL: number;
    encryptionPolicy: 'strict' | 'allow_partial' | 'require_majority';
    keyRequestRateLimit: number;
    keyRequestMaxDelay: number;
    keyRequestWindowSize: number;
    maxSenderKeyCacheSize: number;
    maxDistributionCacheSize: number;
    senderKeyEnvelopeUploadCacheTTL: number;
    distributionCacheTTL: number;
    deviceCacheTTL: number;
    maxDecryptRetries: number;
    maxEncryptRetries: number;
    retryDelayMs: number;
    firstLoginEnvelopeGraceMs: number;
    metricsEnabled: boolean;
    metricsSampleRate: number;
    debugEnabled: boolean;
    verboseLogging: boolean;
    fileInvalidTTL: number;
}
export declare const DEFAULT_E2EE_CONFIG: E2EEConfig;
export declare class E2EEConfigManager {
    private static instance;
    private config;
    private listeners;
    private constructor();
    static getInstance(): E2EEConfigManager;
    getConfig(): E2EEConfig;
    updateConfig(updates: Partial<E2EEConfig>): void;
    resetToDefault(): void;
    addListener(listener: (config: E2EEConfig) => void): void;
    removeListener(listener: (config: E2EEConfig) => void): void;
    private loadFromStorage;
    private saveToStorage;
    private notifyListeners;
    validateConfig(config: Partial<E2EEConfig>): string[];
}
