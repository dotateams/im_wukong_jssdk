export declare function parseSenderKeyStorageKey(key: string): {
    uid: string;
    groupId: string;
    senderUid: string;
    senderDeviceId: string;
} | undefined;
/**
 * 迁移 localStorage 中的 sender keys 到 IndexedDB
 *
 * 迁移策略：
 * 1. 遍历 localStorage 中所有以 'signal_sender_key_' 开头的 key
 * 2. 解析数据并存储到 IndexedDB 的 senderKeys 表
 * 3. 迁移完成后可选择是否删除 localStorage 中的旧数据
 *
 * @param uid 用户 ID
 * @param deviceId 设备 ID
 * @param deleteOldData 是否删除 localStorage 中的旧数据（默认 false）
 * @returns 迁移统计信息
 */
export declare function migrateSenderKeysFromLocalStorage(uid: string, deviceId: string | number, deleteOldData?: boolean): Promise<{
    total: number;
    success: number;
    failed: number;
    errors: {
        key: string;
        error: any;
    }[];
}>;
/**
 * 检查 localStorage 中是否还有旧的 sender key 数据
 */
export declare function hasLocalStorageSenderKeys(): boolean;
/**
 * 删除 localStorage 中所有的旧 sender key 数据
 *
 * @returns 删除的数量
 */
export declare function clearLocalStorageSenderKeys(): number;
