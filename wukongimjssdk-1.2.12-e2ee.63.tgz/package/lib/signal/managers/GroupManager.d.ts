import { SignalProtocolStore as SignalProtocolStoreClass } from '../storage/SignalProtocolStore';
import { SenderKeyState } from '../models/SenderKeyState';
import { SenderKeyRecord } from '../models/SenderKeyRecord';
export declare class GroupManager {
    parent: any;
    uid: any;
    deviceId: any;
    groupEncryptionLocks: Map<any, any>;
    signalStore: SignalProtocolStoreClass;
    groupEnvelopeRecoveryPromises: Map<string, Promise<boolean>>;
    private senderKeyCache;
    private senderKeyStateCache;
    private senderKeyEnvelopeUploadCache;
    private senderKeyEnvelopeUploadPromises;
    private senderKeyDistributionPreparedCache;
    private senderKeyEnvelopeMissingCache;
    private senderKeyEnvelopeForceLookupCache;
    private senderKeyRepairRequestCache;
    private senderKeyRepairBatchQueue;
    private senderKeyRepairBatchTimer;
    private senderKeyEnvelopeLookupBatchQueue;
    private senderKeyEnvelopeLookupBatchTimer;
    private readonly senderKeyDistributionRetryWindow;
    private readonly senderKeyDistributionInterval;
    private readonly senderKeyEnvelopeRecoveryMaxAttempts;
    private readonly senderKeyEnvelopeRecoveryBaseDelayMs;
    private readonly senderKeyEnvelopeForceLookupCooldownMs;
    private readonly senderKeyEnvelopeMissingPersistentTtlMs;
    private readonly senderKeyEnvelopeMissingPersistentMaxEntries;
    private senderKeyEnvelopeMissingNextCleanupAt;
    private senderKeyEnvelopeMissingPersistentClearPromise?;
    private readonly firstLoginEnvelopeGraceMs;
    private firstLoginGraceUntil;
    senderKeyEnvelopeConcurrency: number;
    senderKeyEnvelopeUploadBatchSize: number;
    senderKeyEnvelopeUploadTargetBytes: number;
    senderKeyEnvelopeUploadConcurrency: number;
    senderKeyEnvelopeUploadMaxAttempts: number;
    senderKeyEnvelopeUploadRetryDelayMs: number;
    private identityRepairGeneration;
    private identityRepairDistributionGroups;
    private groupStateLastCheckedAt;
    private groupStateVersions;
    private groupStateCheckPromises;
    private groupStateBatchQueue;
    private groupStateBatchTimer;
    private groupStateUnsupportedUntil;
    constructor(parent: any, uid: any, deviceId: any);
    /**
     * 生成缓存键
     */
    private getCacheKey;
    /**
     * 获取缓存统计信息
     */
    getCacheStats(): {
        senderKeyCache: {
            size: number;
            hitRate: number;
        };
        senderKeyStateCache: {
            size: number;
            hitRate: number;
        };
    };
    markLocalIdentityRepaired(): void;
    markFirstLoginKeyRegistrationComplete(graceMs?: number): void;
    private getIdentityRepairDistributionKey;
    private shouldReuploadAfterIdentityRepair;
    private markIdentityRepairDistributionDone;
    normalizeMemberHash(memberHash: any, members: any): any;
    /**
     * 从成员列表计算 memberHash（用于确保一致性）
     * @param members 成员列表，格式为 { uid: string, deviceIds: (string | number)[] }[]
     * @returns MD5 hash of sorted uids
     */
    calculateMemberHashFromMembers(members: any): string;
    calculateMemberUidHashFromMembers(members: any): string;
    private normalizeRotationMemberHash;
    private normalizeMemberDeviceIds;
    createSenderKeyState(existingRecord: any): Promise<SenderKeyState>;
    createSenderKeyRecord(groupId: any, memberHash: any, existingRecord: any): Promise<any>;
    loadSenderKeyRecord(groupId: any, senderUid: any, senderDeviceId: any): Promise<SenderKeyRecord | null>;
    saveSenderKeyRecord(groupId: any, senderUid: any, record: any, senderDeviceId: any): Promise<void>;
    deleteSenderKeyRecord(groupId: any, senderUid: any, senderDeviceId?: any): Promise<void>;
    deleteGroupSenderKeys(groupId: string): Promise<void>;
    deleteUserSenderKeys(senderUid: string): Promise<void>;
    prepareGroupSend(groupId: any, members: any, memberHash: any): Promise<any>;
    encryptGroupMessage(groupId: any, plaintext: string, members: any, memberHash: any): Promise<any>;
    private scheduleGroupStateCheck;
    private flushGroupStateBatchQueue;
    private applyGroupStateResult;
    private invalidatePreparedDistributionForGroup;
    uploadDistributionEnvelopes(groupId: any, distribution: any): Promise<void>;
    private chunkSenderKeyEnvelopes;
    private estimateUTF8Bytes;
    private uploadDistributionEnvelopesMultipart;
    private buildCompactSenderKeyEnvelopePartPayload;
    private uploadSenderKeyEnvelopePartWithRetry;
    private commitSenderKeyEnvelopeUploadWithRetry;
    private isMultipartUploadUnsupported;
    private createSenderKeyEnvelopeUploadId;
    private buildCompactSenderKeyEnvelopeUploadPayload;
    uploadPendingRepairEnvelopes(groupId: any, record: any, memberHash: string, options?: {
        background?: boolean;
    }): Promise<number>;
    private normalizeRepairRequests;
    private repairRequestsToMembers;
    private getSenderKeyRepairRequestCacheKey;
    invalidateGroupRepairRequestCache(groupId: any): void;
    private getSenderKeyRepairRequestCache;
    private getSenderKeyEnvelopeUploadCache;
    private getSenderKeyDistributionPreparedCache;
    markSenderKeyDistributionPrepared(groupId: any, record: any, members: any[], memberHash: string): void;
    private isSenderKeyDistributionPrepared;
    private getSenderKeyDistributionPreparedKey;
    private getSenderKeyEnvelopeUploadCacheKey;
    shouldRetrySenderKeyDistribution(record: any, payload: any): boolean;
    private buildEnvelopeCiphertextsForMembers;
    buildDistributionPayloadForRecord(groupId: any, record: any, members: any, normalizedMemberHash: string): Promise<{
        type: string;
        group_id: any;
        sender_uid: any;
        sender_device_id: any;
        key_id: any;
        version: any;
        member_hash: string;
        kdf_ver: any;
        distribution: {
            type: string;
            ciphertexts: any[];
        };
    } | null>;
    buildGroupDistributionMessage(groupId: any, memberHash: any, forceNewKey: boolean): Promise<{
        plain: string;
        keyId: any;
        memberHash: any;
        kdfVersion: any;
    } | null>;
    encryptGroupDistribution(groupId: any, members: any, memberHash: any, forceNewKey: boolean): Promise<{
        type: number;
        body: string;
    } | null>;
    decryptGroupMessageObject(obj: any, remoteUid: string, remoteDeviceId: any): Promise<any>;
    private hasSenderKeyState;
    recoverSenderKeyFromEnvelope(obj: any, senderUid: string, senderDeviceId: any, options?: {
        force?: boolean;
        reason?: string;
    }): Promise<boolean>;
    private requestSenderKeyRepair;
    private enqueueSenderKeyRepairRequest;
    private flushSenderKeyRepairBatchQueue;
    private getSenderKeyEnvelopeMissingCache;
    private getSenderKeyEnvelopeForceLookupCache;
    private markSenderKeyEnvelopeMissing;
    private getPersistentSenderKeyEnvelopeMissingKey;
    private getPersistentSenderKeyEnvelopeMissingPrefix;
    private getPersistentSenderKeyEnvelopeMissing;
    private setPersistentSenderKeyEnvelopeMissing;
    private clearPersistentSenderKeyEnvelopeMissingCache;
    private schedulePersistentSenderKeyEnvelopeMissingCleanup;
    private doRecoverSenderKeyFromEnvelope;
    private lookupGroupSenderKeyEnvelopeWithRetry;
    private enqueueGroupSenderKeyEnvelopeLookup;
    private flushGroupSenderKeyEnvelopeLookupBatchQueue;
    private groupSenderKeyEnvelopeLookupCacheKey;
    private isPermanentEnvelopeLookupError;
    private shouldCacheEnvelopeLookupFailure;
    private shouldStopEnvelopeLookupRetry;
    private isEnvelopeNotReadyError;
    private isWithinFirstLoginGrace;
    private isMissingMessageKeyError;
    private delay;
    private logPerf;
    private now;
    decryptGroupDistributionObject(obj: any, remoteUid: string, remoteDeviceId: any): Promise<void>;
    getStatesByKeyIds(record: SenderKeyRecord, keyIds: number[]): SenderKeyState[];
    buildGroupDistributionBatch(groupId: any, memberHash: any, keyIds?: number[]): Promise<{
        group_id: any;
        sender_uid: any;
        sender_device_id: any;
        distributions: {
            key_id: number;
            member_hash: string;
            kdf_ver: string;
            distribution_plain?: string | undefined;
            error?: string | undefined;
        }[];
    } | null>;
}
