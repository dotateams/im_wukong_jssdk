export declare const E2EE_CACHE_STORES: {
    PLAINTEXT: string;
    THUMBNAILS: string;
    CHANNEL_DEVICES: string;
    ENVELOPE_MISSING: string;
};
export declare class E2EECacheStore {
    private dbPromise?;
    private static instance;
    static shared(): E2EECacheStore;
    get(storeName: string, key: string): Promise<any>;
    set(storeName: string, key: string, value: any): Promise<void>;
    delete(storeName: string, key: string): Promise<void>;
    clearPrefix(storeName: string, prefix: string): Promise<void>;
    scheduleLegacyMigration(storeName: string, prefix: string): void;
    pruneExpiringEntries(storeName: string, maxEntries: number, batchSize?: number): Promise<boolean>;
    private migrateLegacyKey;
    private open;
    private request;
    private transaction;
    private readLegacyKey;
    private removeLegacyKey;
    private writeLegacyKey;
    private serializeLegacyValue;
    private parseExpiringValue;
    private legacyKeys;
    private removeLegacyPrefix;
    private legacyStorages;
}
