import { SignalProtocolStore as SignalProtocolStoreClass } from '../storage/SignalProtocolStore';
import { SenderKeyState } from '../models/SenderKeyState';
import { SenderKeyRecord } from '../models/SenderKeyRecord';
export declare class GroupManager {
    parent: any;
    uid: any;
    deviceId: any;
    groupEncryptionLocks: Map<any, any>;
    signalStore: SignalProtocolStoreClass;
    groupEnvelopeRecoveryPromises: Map<string, Promise<boolean>>;
    private senderKeyCache;
    private senderKeyStateCache;
    private senderKeyEnvelopeUploadCache;
    private senderKeyEnvelopeUploadPromises;
    private senderKeyEnvelopeMissingCache;
    private senderKeyEnvelopeForceLookupCache;
    private senderKeyRepairRequestCache;
    private readonly senderKeyDistributionRetryWindow;
    private readonly senderKeyDistributionInterval;
    private readonly senderKeyEnvelopeRecoveryMaxAttempts;
    private readonly senderKeyEnvelopeRecoveryBaseDelayMs;
    senderKeyEnvelopeConcurrency: number;
    private identityRepairGeneration;
    private identityRepairDistributionGroups;
    constructor(parent: any, uid: any, deviceId: any);
    /**
     * 生成缓存键
     */
    private getCacheKey;
    /**
     * 获取缓存统计信息
     */
    getCacheStats(): {
        senderKeyCache: {
            size: number;
            hitRate: number;
        };
        senderKeyStateCache: {
            size: number;
            hitRate: number;
        };
    };
    markLocalIdentityRepaired(): void;
    private getIdentityRepairDistributionKey;
    private shouldReuploadAfterIdentityRepair;
    private markIdentityRepairDistributionDone;
    normalizeMemberHash(memberHash: any, members: any): any;
    /**
     * 从成员列表计算 memberHash（用于确保一致性）
     * @param members 成员列表，格式为 { uid: string, deviceIds: (string | number)[] }[]
     * @returns MD5 hash of sorted uids
     */
    calculateMemberHashFromMembers(members: any): string;
    private normalizeMemberDeviceIds;
    createSenderKeyState(existingRecord: any): Promise<SenderKeyState>;
    createSenderKeyRecord(groupId: any, memberHash: any, existingRecord: any): Promise<any>;
    loadSenderKeyRecord(groupId: any, senderUid: any, senderDeviceId: any): Promise<SenderKeyRecord | null>;
    saveSenderKeyRecord(groupId: any, senderUid: any, record: any, senderDeviceId: any): Promise<void>;
    deleteSenderKeyRecord(groupId: any, senderUid: any, senderDeviceId?: any): Promise<void>;
    deleteGroupSenderKeys(groupId: string): Promise<void>;
    deleteUserSenderKeys(senderUid: string): Promise<void>;
    prepareGroupSend(groupId: any, members: any, memberHash: any): Promise<any>;
    encryptGroupMessage(groupId: any, plaintext: string, members: any, memberHash: any): Promise<any>;
    uploadDistributionEnvelopes(groupId: any, distribution: any): Promise<void>;
    uploadPendingRepairEnvelopes(groupId: any, record: any, memberHash: string): Promise<number>;
    private normalizeRepairRequests;
    private repairRequestsToMembers;
    private getSenderKeyRepairRequestCacheKey;
    private getSenderKeyRepairRequestCache;
    private getSenderKeyEnvelopeUploadCache;
    private getSenderKeyEnvelopeUploadCacheKey;
    shouldRetrySenderKeyDistribution(record: any, payload: any): boolean;
    private buildEnvelopeCiphertextsForMembers;
    buildDistributionPayloadForRecord(groupId: any, record: any, members: any, normalizedMemberHash: string): Promise<{
        type: string;
        group_id: any;
        sender_uid: any;
        sender_device_id: any;
        key_id: any;
        version: any;
        member_hash: string;
        kdf_ver: any;
        distribution: {
            type: string;
            ciphertexts: any[];
        };
    } | null>;
    buildGroupDistributionMessage(groupId: any, memberHash: any, forceNewKey: boolean): Promise<{
        plain: string;
        keyId: any;
        memberHash: any;
        kdfVersion: any;
    } | null>;
    encryptGroupDistribution(groupId: any, members: any, memberHash: any, forceNewKey: boolean): Promise<{
        type: number;
        body: string;
    } | null>;
    decryptGroupMessageObject(obj: any, remoteUid: string, remoteDeviceId: any): Promise<any>;
    private hasSenderKeyState;
    recoverSenderKeyFromEnvelope(obj: any, senderUid: string, senderDeviceId: any, options?: {
        force?: boolean;
        reason?: string;
    }): Promise<boolean>;
    private requestSenderKeyRepair;
    private getSenderKeyEnvelopeMissingCache;
    private getSenderKeyEnvelopeForceLookupCache;
    private doRecoverSenderKeyFromEnvelope;
    private lookupGroupSenderKeyEnvelopeWithRetry;
    private isPermanentEnvelopeLookupError;
    private isMissingMessageKeyError;
    private delay;
    private logPerf;
    private now;
    decryptGroupDistributionObject(obj: any, remoteUid: string, remoteDeviceId: any): Promise<void>;
    getStatesByKeyIds(record: SenderKeyRecord, keyIds: number[]): SenderKeyState[];
    buildGroupDistributionBatch(groupId: any, memberHash: any, keyIds?: number[]): Promise<{
        group_id: any;
        sender_uid: any;
        sender_device_id: any;
        distributions: {
            key_id: number;
            member_hash: string;
            kdf_ver: string;
            distribution_plain?: string | undefined;
            error?: string | undefined;
        }[];
    } | null>;
}
