import { Channel, MessageContent } from "../model";
import type { E2EEDecryptContext, E2EECryptoAdapter, E2EERecoverContext } from "./e2ee_types";
export interface SignalLikeManager {
    deviceId?: string | number;
    getRemoteDevices(uid: string, forceRefresh?: boolean): Promise<any[]>;
    encryptMessage(uid: string, deviceId: string | number, plaintext: string): Promise<any>;
    decryptMessage(uid: string, deviceId: string | number, messageType: any, ciphertext: any): Promise<string>;
    encryptGroupMessage?(groupId: string, plaintext: string, members?: any, memberHash?: any): Promise<any>;
    prepareGroupSend?(groupId: string, members?: any, memberHash?: any): Promise<any>;
    requestGroupSenderKeyRepair?(payload: any): Promise<any>;
    lookupGroupSenderKeyRepairRequests?(payload: any): Promise<any>;
    recoverGroupMessageDecryptFailure?(obj: any, senderUid: string, senderDeviceId: any): Promise<boolean>;
    invalidateChannelDevicesCache?(channelId: string, channelType?: any): void;
}
export interface SignalE2EEAdapterOptions {
    localUid?: string;
    localDeviceId: string | number;
    signalManager: SignalLikeManager;
    getGroupMembers?: (groupId: string) => Promise<any[]>;
    getGroupMemberHash?: (groupId: string, members: any[]) => string | Promise<string>;
}
export declare class SignalE2EEAdapter implements E2EECryptoAdapter {
    private localUid?;
    private localDeviceId;
    private signalManager;
    private getGroupMembers?;
    private getGroupMemberHash?;
    private groupMembersCache;
    private groupMembersPromises;
    constructor(options: SignalE2EEAdapterOptions);
    prewarmChannel(channel: Channel): Promise<void>;
    prepareGroupSend(channel: Channel): Promise<void>;
    invalidateGroupMemberCache(groupId: string): void;
    clearLocalData(): Promise<void>;
    encryptMessage(content: MessageContent, channel: Channel): Promise<MessageContent>;
    decryptMessage(content: MessageContent, channel: Channel, context?: E2EEDecryptContext): Promise<MessageContent>;
    recoverDecryptFailure(content: MessageContent, channel: Channel, context?: E2EERecoverContext): Promise<boolean>;
    private isSignalContent;
    private encryptPerson;
    private getPersonRecipientDevices;
    private encryptGroup;
    private normalizeGroupEncryptedPayload;
    private getGroupMembersForEncrypt;
    private buildSignalContent;
    private encodeContentToPlaintext;
    private decodePlaintextToContent;
    private stringToUint8Array;
    private resolveSenderUid;
}
