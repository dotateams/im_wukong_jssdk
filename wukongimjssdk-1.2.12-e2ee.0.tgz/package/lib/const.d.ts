export declare class MessageContentType {
    static unknown: number;
    static text: number;
    static image: number;
    static stream: number;
    static cmd: number;
    static signalMessage: number;
}
