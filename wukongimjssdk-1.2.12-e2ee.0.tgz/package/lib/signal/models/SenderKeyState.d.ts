import CryptoJS from 'crypto-js';
export declare class SenderKeyState {
    keyId: any;
    senderKey: any;
    chainKey: any;
    signingPubKey: any;
    signingPrivKey: any;
    messageIndex: number;
    skipped: any;
    kdfVersion: string;
    constructor({ keyId, senderKey, chainKey, signingPubKey, signingPrivKey, messageIndex, skipped, kdfVersion, }: any);
    static fromDistribution(message: any): SenderKeyState;
    static fromStorage(obj: any): SenderKeyState | null;
    serialize(): {
        key_id: any;
        sender_key: any;
        chain_key: any;
        msg_index: number;
        skipped: any;
        signing_pub_key: any;
        signing_priv_key: any;
        kdf_ver: string;
    };
    nextMessageKeyForSending(): {
        messageKey: string;
        msgIndex: number;
    };
    getMessageKeyForIndex(targetIndex: number): {
        messageKey: any;
    };
    deriveMessageKey(chainKeyBase64: string): {
        messageKey: string;
        nextChainKey: string;
    };
    hkdfExpand(prkWord: any, info: any, lengthBytes: number): CryptoJS.lib.WordArray;
    trimSkippedKeys(skipped: any): any;
}
