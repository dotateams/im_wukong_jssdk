import { SenderKeyRecord } from '../models/SenderKeyRecord';
export declare class SignalProtocolStore {
    uid: string;
    deviceId: string | number;
    db: IDBDatabase | null;
    constructor(uid: string, deviceId: string | number);
    init(): Promise<void>;
    private _identityKey;
    getIdentityKeyPair(): Promise<any>;
    saveIdentityKeyPair(keyPair: any): Promise<void>;
    getLocalRegistrationId(): Promise<any>;
    saveLocalRegistrationId(id: any): Promise<void>;
    saveIdentity(encodedAddress: string, identityKey: any): Promise<boolean>;
    isTrustedIdentity(encodedAddress: string, identityKey: any, direction: any): Promise<boolean>;
    getIdentity(encodedAddress: string): Promise<any>;
    loadPreKey(preKeyId: any): Promise<any>;
    storePreKey(preKeyId: any, keyPair: any): Promise<void>;
    removePreKey(preKeyId: any): Promise<void>;
    loadSignedPreKey(signedPreKeyId: any): Promise<any>;
    storeSignedPreKey(signedPreKeyId: any, keyPair: any): Promise<void>;
    removeSignedPreKey(signedPreKeyId: any): Promise<void>;
    loadSession(encodedAddress: string): Promise<any>;
    storeSession(encodedAddress: string, record: any): Promise<void>;
    deleteSession(encodedAddress: string): Promise<void>;
    clearSessions(): Promise<void>;
    loadKyberPreKey(kyberPreKeyId: any): Promise<any>;
    saveKyberPreKey(kyberPreKeyId: any, record: any): Promise<void>;
    _get(storeName: string, key: any): Promise<any>;
    _getWithKeyAliases(storeName: string, key: any): Promise<any>;
    private _keyAliases;
    _put(storeName: string, key: any, value: any): Promise<void>;
    _delete(storeName: string, key: any): Promise<void>;
    _clear(storeName: string): Promise<void>;
    _putForSenderKeys(value: any): Promise<void>;
    saveSenderKeyRecord(groupId: string, senderUid: string, record: SenderKeyRecord, senderDeviceId: string | number): Promise<void>;
    loadSenderKeyRecord(groupId: string, senderUid: string, senderDeviceId?: string | number): Promise<SenderKeyRecord | null>;
    /**
     * 删除指定的 sender key 记录
     * @param groupId 群组 ID
     * @param senderUid 发送者用户 ID
     * @param senderDeviceId 发送者设备 ID（可选）
     */
    deleteSenderKeyRecord(groupId: string, senderUid: string, senderDeviceId?: string | number): Promise<void>;
    /**
     * 删除指定群组的所有 sender keys
     * @param groupId 群组 ID
     */
    deleteGroupSenderKeys(groupId: string): Promise<void>;
    /**
     * 删除指定用户的所有 sender keys（跨所有群组）
     * @param senderUid 发送者用户 ID
     */
    deleteUserSenderKeys(senderUid: string): Promise<void>;
    /**
     * 删除过期的 sender keys 记录
     * @param expiryTime 过期时间戳（毫秒），所有 updatedAt 小于该时间的记录将被删除
     */
    deleteExpiredSenderKeys(expiryTime: number): Promise<number>;
}
