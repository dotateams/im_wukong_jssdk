export declare class PreKeyManager {
    uid: any;
    deviceId: any;
    deviceName: any;
    apiClient: any;
    store: any;
    toBase64: (data: any) => string;
    ensureWebCrypto: () => void;
    preKeyTimer: any;
    signedPreKeyTimer: any;
    lastPreKeyCheckAt: any;
    constructor(params: {
        uid: any;
        deviceId: any;
        deviceName: any;
        apiClient: any;
        store: any;
        toBase64: (data: any) => string;
        ensureWebCrypto: () => void;
    });
    initialize(): Promise<void>;
    generateRegistrationId(): number;
    generateSignedPreKeyId(): number;
    getPreKeyNextIdStorageKey(): string;
    isSuccessResponse(resp: any): boolean;
    getResponseData(resp: any): any;
    generateSignedPreKey(keyId: any, identityKeyPair: any): Promise<any>;
    generatePreKeys(startId: number, count: number): Promise<any[]>;
    generatePreKeyBundle(): Promise<{
        uid: any;
        device_id: any;
        device_name: any;
        platform: string;
        identity_key: string;
        registration_id: number;
        signed_prekey: {
            key_id: number;
            public_key: string;
            signature: string;
        };
        prekeys: {
            key_id: any;
            public_key: string;
        }[];
    }>;
    isCurrentDeviceRegistered(): Promise<boolean>;
    getCurrentDeviceRegistration(): Promise<{
        registered: boolean;
        signedPreKeyId: number;
    }>;
    getSignedPreKeyIdFromBundle(bundle: any): number;
    hasLocalSignedPreKey(keyId: any): Promise<boolean>;
    generateBundleForExistingIdentity(identityKeyPair: any, signedPreKeyId?: any): Promise<{
        uid: any;
        device_id: any;
        device_name: any;
        platform: string;
        identity_key: string;
        registration_id: any;
        signed_prekey: {
            key_id: any;
            public_key: string;
            signature: string;
        };
        prekeys: {
            key_id: any;
            public_key: string;
        }[];
    }>;
    uploadPreKeys(bundle: any): Promise<any>;
    uploadOnetimePreKeys(bundle: any): Promise<any>;
    useOnetimePreKeys(bundle: any): Promise<any>;
    maybeCheckAndRefillPreKeys(): void;
    checkAndRefillPreKeys(): Promise<void>;
    rotateSignedPreKey(): Promise<void>;
    startMaintenance(): void;
    stopMaintenance(): void;
}
