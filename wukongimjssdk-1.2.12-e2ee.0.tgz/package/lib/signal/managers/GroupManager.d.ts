import { SignalProtocolStore as SignalProtocolStoreClass } from '../storage/SignalProtocolStore';
import { SenderKeyState } from '../models/SenderKeyState';
import { SenderKeyRecord } from '../models/SenderKeyRecord';
export declare class GroupManager {
    parent: any;
    uid: any;
    deviceId: any;
    groupEncryptionLocks: Map<any, any>;
    signalStore: SignalProtocolStoreClass;
    private senderKeyCache;
    private senderKeyStateCache;
    private readonly senderKeyDistributionRetryWindow;
    constructor(parent: any, uid: any, deviceId: any);
    /**
     * 生成缓存键
     */
    private getCacheKey;
    /**
     * 获取缓存统计信息
     */
    getCacheStats(): {
        senderKeyCache: {
            size: number;
            hitRate: number;
        };
        senderKeyStateCache: {
            size: number;
            hitRate: number;
        };
    };
    normalizeMemberHash(memberHash: any, members: any): any;
    /**
     * 从成员列表计算 memberHash（用于确保一致性）
     * @param members 成员列表，格式为 { uid: string, deviceIds: (string | number)[] }[]
     * @returns MD5 hash of sorted uids
     */
    calculateMemberHashFromMembers(members: any): string;
    createSenderKeyState(existingRecord: any): Promise<SenderKeyState>;
    createSenderKeyRecord(groupId: any, memberHash: any, existingRecord: any): Promise<any>;
    loadSenderKeyRecord(groupId: any, senderUid: any, senderDeviceId: any): Promise<SenderKeyRecord | null>;
    saveSenderKeyRecord(groupId: any, senderUid: any, record: any, senderDeviceId: any): Promise<void>;
    deleteSenderKeyRecord(groupId: any, senderUid: any, senderDeviceId?: any): Promise<void>;
    deleteGroupSenderKeys(groupId: string): Promise<void>;
    deleteUserSenderKeys(senderUid: string): Promise<void>;
    encryptGroupMessage(groupId: any, plaintext: string, members: any, memberHash: any): Promise<any>;
    shouldRetrySenderKeyDistribution(record: any, payload: any): boolean;
    buildDistributionPayloadForRecord(groupId: any, record: any, members: any, normalizedMemberHash: string): Promise<{
        type: string;
        group_id: any;
        sender_uid: any;
        sender_device_id: any;
        key_id: any;
        version: any;
        member_hash: string;
        kdf_ver: any;
        distribution: {
            type: string;
            ciphertexts: any[];
        };
    } | null>;
    buildGroupDistributionMessage(groupId: any, memberHash: any, forceNewKey: boolean): Promise<{
        plain: string;
        keyId: any;
        memberHash: any;
        kdfVersion: any;
    } | null>;
    encryptGroupDistribution(groupId: any, members: any, memberHash: any, forceNewKey: boolean): Promise<{
        type: number;
        body: string;
    } | null>;
    decryptGroupMessageObject(obj: any, remoteUid: string, remoteDeviceId: any): Promise<any>;
    decryptGroupDistributionObject(obj: any, remoteUid: string, remoteDeviceId: any): Promise<void>;
    getStatesByKeyIds(record: SenderKeyRecord, keyIds: number[]): SenderKeyState[];
    buildGroupDistributionBatch(groupId: any, memberHash: any, keyIds?: number[]): Promise<{
        group_id: any;
        sender_uid: any;
        sender_device_id: any;
        distributions: {
            key_id: number;
            member_hash: string;
            kdf_ver: string;
            distribution_plain?: string | undefined;
            error?: string | undefined;
        }[];
    } | null>;
}
