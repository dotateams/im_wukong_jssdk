import { Channel, MessageContent } from "../model";
import type { E2EEDecryptContext, E2EECryptoAdapter } from "./e2ee_types";
export interface SignalLikeManager {
    deviceId?: string | number;
    getRemoteDevices(uid: string, forceRefresh?: boolean): Promise<any[]>;
    encryptMessage(uid: string, deviceId: string | number, plaintext: string): Promise<any>;
    decryptMessage(uid: string, deviceId: string | number, messageType: any, ciphertext: any): Promise<string>;
    encryptGroupMessage?(groupId: string, plaintext: string, members?: any, memberHash?: any): Promise<any>;
}
export interface SignalE2EEAdapterOptions {
    localUid?: string;
    localDeviceId: string | number;
    signalManager: SignalLikeManager;
    getGroupMembers?: (groupId: string) => Promise<any[]>;
    getGroupMemberHash?: (groupId: string, members: any[]) => string | Promise<string>;
}
export declare class SignalE2EEAdapter implements E2EECryptoAdapter {
    private localUid?;
    private localDeviceId;
    private signalManager;
    private getGroupMembers?;
    private getGroupMemberHash?;
    constructor(options: SignalE2EEAdapterOptions);
    encryptMessage(content: MessageContent, channel: Channel): Promise<MessageContent>;
    decryptMessage(content: MessageContent, channel: Channel, context?: E2EEDecryptContext): Promise<MessageContent>;
    private isSignalContent;
    private encryptPerson;
    private getPersonRecipientDevices;
    private encryptGroup;
    private normalizeGroupEncryptedPayload;
    private buildSignalContent;
    private encodeContentToPlaintext;
    private decodePlaintextToContent;
    private stringToUint8Array;
    private resolveSenderUid;
}
