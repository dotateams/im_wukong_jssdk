import type { Channel, MessageContent } from "../model";
import type { E2EEDecryptContext, E2EEInitOptions, E2EESendPlan, ResolveSendPlanOptions } from "./e2ee_types";
export declare class E2EEManager {
    private options?;
    get initialized(): boolean;
    get currentOptions(): E2EEInitOptions | undefined;
    initialize(options: E2EEInitOptions): Promise<void>;
    reset(): void;
    resolveSendPlan(channel: Channel, _content: MessageContent, options?: ResolveSendPlanOptions): Promise<E2EESendPlan>;
    encryptMessage(content: MessageContent, channel: Channel): Promise<MessageContent>;
    decryptMessage(content: MessageContent, channel: Channel, context?: E2EEDecryptContext): Promise<MessageContent>;
    private resolveChannelInfo;
    private preflightChannelInfo;
    private normalizeChannelInfo;
    private normalizeOptions;
}
